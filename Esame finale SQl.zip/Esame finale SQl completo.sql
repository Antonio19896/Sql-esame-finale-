CREATE DATABASE ToysGroupDB;
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(50),
    Category VARCHAR(50)
);
CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(50)
);
CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    ProductID INT,
    RegionID INT,
    SalesDate DATE,
    Quantity INT,
    Price Decimal(10,2),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);
INSERT INTO Product (ProductID, ProductName, Category) VALUES
(1, 'Cane', 'Peluche'),
(2, 'AF One piece', 'Action figure'),
(3, 'AF Naruto', 'Action Figure'),
(4, 'Lego set Mclaren', 'Lego'),
(5, 'Barbie', 'Barbie'),
(6, 'Telefono Giocattolo', 'Telefono'),
(7, 'Risiko', 'Giochi Da Tavolo'),
(8, 'Lego set Ferrrari', 'Lego'),
(9, 'Cucina giocattolo', 'Cucina Giocattolo'),
(10, 'Orsetto', 'Peluche');

INSERT INTO Region (RegionID, RegionName) VALUES
(1, 'Italia'),
(2, 'Germania'),
(3, 'Corea Del Sud'),
(4, 'USA'),
(5, 'Canada'),
(6, 'Cina');

INSERT INTO Sales (SalesID, ProductID, RegionID, SalesDate, Quantity, Price) VALUES
(1, 1, 1, '2024-01-15', 100, 20.00),
(2, 2, 2, '2024-01-20', 150, 15.00),
(3, 3, 3, '2024-01-25', 200, 30.00),
(4, 1, 2, '2024-02-01', 50, 20.00),
(5, 3, 1, '2024-02-05', 75, 30.00),
(6, 4, 4, '2024-02-12', 120, 45.00),
(7, 5, 5, '2024-05-15', 60, 25.00),
(8, 6, 6, '2024-02-20', 80, 10.00),
(9, 7, 1, '2024-03-01', 90, 35.00),
(10, 8, 2, '2024-03-05', 110, 50.00),
(11, 9, 3, '2024-03-10', 130, 60.00),
(12, 9, 4, '2024-03-15', 140, 40.00),
(13, 2, 5, '2024-03-20', 150, 25.00),
(14, 3, 6, '2024-07-25', 160, 30.00),
(15, 4, 1, '2024-04-01', 170, 45.00),
(16, 5, 2, '2024-04-05', 180, 25.00),
(17, 6, 3, '2024-04-10', 190, 10.00),
(18, 7, 4, '2024-04-15', 200, 35.00),
(19, 8, 5, '2024-04-20', 220, 54.00),
(20, 4, 1, '2024-04-01', 170, 45.00),
(21, 5, 2, '2024-04-05', 180, 25.00),
(22, 6, 3, '2024-04-10', 190, 10.00),
(23, 7, 4, '2024-04-15', 200, 35.00),
(24, 8, 5, '2024-04-20', 210, 50.00),
(25, 9, 6, '2024-04-25', 220, 60.00),
(26, 6, 6, '2023-06-05', 100, 10.00),
(27, 7, 1, '2023-07-10', 110, 35.00),
(28, 8, 2, '2023-08-15', 120, 50.00),
(29, 9, 3, '2023-09-20', 130, 60.00),
(30, 1, 4, '2023-10-25', 140, 40.00),
(31, 2, 5, '2023-11-30', 150, 15.00),
(32, 3, 6, '2023-12-05', 160, 30.00),
(33, 1, 1, '2023-01-10', 50, 20.00),
(34, 2, 2, '2023-02-15', 60, 15.00),
(35, 3, 3, '2023-03-20', 70, 30.00),
(36, 4, 4, '2023-04-25', 80, 45.00),
(37, 5, 5, '2023-05-30', 90, 25.00);

SELECT ProductID, COUNT(*)
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;


SELECT RegionID, COUNT(*)
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;



SELECT SalesID, COUNT(*)
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1;


Create view Fatturato_Prodotti_per_anno as (SELECT
    P.ProductName,
    YEAR(S.SalesDate) AS Year,
    SUM(S.Quantity * S.Price) AS TotalRevenue
FROM
    Sales S
    JOIN Product P ON S.ProductID = P.ProductID
GROUP BY
    P.ProductName,
    YEAR(S.SalesDate));
    
    Create view Fatturato_per_regione AS (SELECT
    R.RegionName,
    YEAR(S.SalesDate) AS Year,
    SUM(S.Quantity * S.Price) AS TotalRevenue
FROM
    Sales S
    JOIN Region R ON S.RegionID = R.RegionID
GROUP BY
    R.RegionName,
    YEAR(S.SalesDate)
ORDER BY
    YEAR(S.SalesDate),
    TotalRevenue DESC);
    
    
    Create view Categoria_più_richiesta As (SELECT
    P.Category,
    SUM(S.Quantity) AS Total_quantity_sales
FROM
    Sales S
    JOIN Product P ON S.ProductID = P.ProductID
GROUP BY
    P.Category
ORDER BY
    Total_quantity_sales DESC
LIMIT 1);



Create View Prodotti_invenduti_1 as (SELECT
    P.ProductName
FROM
    Product P
WHERE
    P.ProductID NOT IN (
        SELECT S.ProductID
        FROM Sales S
    ));
    
    Create view Prodotti_invenduti_2 as (SELECT
    P.ProductName
FROM
    Product P
    LEFT JOIN Sales S ON P.ProductID = S.ProductID
WHERE
    S.SalesID IS NULL);

Create view Data_ultima_vendita As (SELECT
    P.ProductName,
    MAX(S.SalesDate) AS LastSaleDate
FROM
    Sales S
    JOIN Product P ON S.ProductID = P.ProductID
GROUP BY
    P.ProductName);